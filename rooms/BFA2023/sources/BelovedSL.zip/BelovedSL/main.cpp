using namespace std;

#include <iostream>

/*
 * SECTION PROBLEM 1: PERFECT TERNARY TREE PATHS
 * Given a height >= 1, enumerate all paths of a perfect ternary tree with that height.
 *
 * A ternary tree is a tree where each node has up to three children.
 *
 * A perfect ternary tree is a ternary tree where all leaves have the same depth, and all internal nodes
 * have three children.
 *
 * These paths should be returned as a concatenation of the paths, where a left node traversal should
 * come before a middle node traversal, and a middle node traversal should come before a right node traversal.
 *
 * For example, consider a perfect ternary tree of height 3.
 * Paths:
 * - LL
 * - LM
 * - LR
 * - ML
 * - MM
 * - MR
 * - RL
 * - RM
 * - RR
 *
 * Thus, the correct return string is:
 * LLLMLRMLMMMRRLRMRR
 *
 * Notice that a perfect ternary tree of height 1 (a single node) would have an empty string result.
 */
string perfectTernaryTreePaths(int height) {
    // TODO: Implement this function
    return "";
}


/* DO NOT EDIT CODE OR SET BREAKPOINTS BELOW THIS LINE */
int main() {
    // Recite for a height of 8
    cout << perfectTernaryTreePaths(8) << endl;
    return 0;
}
