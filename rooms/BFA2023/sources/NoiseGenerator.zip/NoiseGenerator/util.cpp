#include "queue.h"
#include "vector.h"
#include "filelib.h"
#include "strlib.h"

using namespace std;

void load(Queue<bool>& motorSequence, Vector<int>& pitches) {
    // Load motor sequence
    ifstream motorSequenceIn;
    openFile(motorSequenceIn, "motor_sequence.txt");
    string motorSequenceString = trim(readEntire(motorSequenceIn));
    for (char bit : motorSequenceString) {
        motorSequence.enqueue(bit == '1');
    }

    // Load pitches
    ifstream pitchesIn;
    openFile(pitchesIn, "pitches.txt");

    string pitchesString = trim(readEntire(pitchesIn));
    Vector<string> pitchesSplit = stringSplit(pitchesString, ",");

    for (const string& pitchStr : pitchesSplit) {
        pitches.add(stringToInteger(pitchStr));
    }
}
