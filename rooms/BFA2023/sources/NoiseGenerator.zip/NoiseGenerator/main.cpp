using namespace std;

#include "queue.h"
#include "util.h"

/*
 * NOISE GENERATOR - need to make this fast
 *
 * Accepts a motorSequence and pitches as parameters.
 *
 * A motorSequence is a queue of booleans, where true indicates that the generator is moving
 * and false indicates that the generator is stationary. Each dequeued element can be thought of
 * as the generator's movement status for a particular timestep.
 *
 * In order to lure zombies at the right time, we only emit pitches when the generator is
 * stationary. We start with the first pitch in the pitches vector. We should move on
 * to the next pitch after a timestep regardless of whether the generator is stationary at the time.
 * When we have rotated through all the pitches, we will start with the first pitch again.
 * This is to create erratic sounds, which has a higher chance of attracting zombies.
 *
 * Consider the example below.
 * Motor sequence: <- {true, true, false, true, false} <-
 * Pitches: {113, 90, 85}
 * The correct sequence of emitted pitches is {85, 90}.
 *
 * See below for a timestep diagram.
 *  T1    T2    T3     T4    T5
 *  true  true  false  true  false
 *  113   90    85     113   90
 *
 *  Return the sequence of emitted pitches as a vector of integers in timestep order.
 */
Vector<int> runNoiseGenerator(Queue<bool> motorSequence, Vector<int> pitches) {
    // TODO: Fill in this function
    return {};
}

/* DO NOT EDIT CODE OR SET BREAKPOINTS BELOW THIS LINE */
int main() {
    Queue<bool> motorSequence;
    Vector<int> pitches;
    load(motorSequence, pitches);

    Vector<int> collectedPitches = runNoiseGenerator(motorSequence, pitches);
    string message = "";
    for (int pitch : collectedPitches) {
        message += (char) pitch;
    }

    cout << message << endl;
    return 0;
}
