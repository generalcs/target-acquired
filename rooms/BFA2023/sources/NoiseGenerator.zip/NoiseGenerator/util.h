#ifndef UTIL_H
#define UTIL_H

#include "queue.h"
#include "vector.h"

void load(Queue<bool>& motorSequence, Vector<int>& pitches);

#endif // UTIL_H
