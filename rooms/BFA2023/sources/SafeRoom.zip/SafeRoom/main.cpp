#include <iostream>
#include "utility.h"

using namespace std;

/*
 * The safe room result list has extraneous nodes that need to be removed.
 * The following functionality will help in this process.
 *
 * Implement a function to remove the k-th element from the end of a linked list.
 * For example, removing k=2 from a -> b -> c -> d would result in a -> b -> d.
 */

void removeKthElement(Node* head, int k) {
    // TODO: Implement this function
}

/* DO NOT EDIT CODE OR SET BREAKPOINTS BELOW THIS LINE */
string getAnswer(Node* head) {
    string fullStr = "";
    while (head) {
        fullStr += head->data;
        head = head->next;
    }

    string output = "";
    const int bounds = 106;
    for (int i = 0; i < (int) fullStr.size(); i++) {
        if (i % bounds == 0 && i != 0) {
            output += fullStr.substr(i, 1);
        }
    }
    return output;
}

int main() {
    Node* list = createList("shortList.txt");
    cout << "Answer is " << getAnswer(list) << endl;

    int listOfKs [17] = {72, 93, 174, 183, 205, 200, 374, 289, 312, 628, 847, 1026, 920, 816, 832, 511, 500};

    for (int k: listOfKs) {
        removeKthElement(list, k);
    }

    cout << "Safe room: " << getAnswer(list) << endl;
    freeList(list);
    return 0;
}
