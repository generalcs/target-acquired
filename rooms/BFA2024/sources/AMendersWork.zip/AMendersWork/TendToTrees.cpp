#include "TendToTrees.h"
using namespace std;

/*
 * Tend to the withering trees by pruning their rotting leaves.
 * Leave everything else untouched.
 *
 * A 'leaf' is defined as a node that has no children.
 * You can find the definition for [TreeNode] in [Util.h].
 */
void removeLeaves(TreeNode*& node) {
    /* TODO: Implement this function. */
    (void) node;
}
