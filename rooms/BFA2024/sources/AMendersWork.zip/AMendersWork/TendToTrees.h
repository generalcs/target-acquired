#include "TreeNode.h"

#ifndef TENDTOTREES_H
#define TENDTOTREES_H

void removeLeaves(TreeNode*& node);

#endif // TENDTOTREES_H
