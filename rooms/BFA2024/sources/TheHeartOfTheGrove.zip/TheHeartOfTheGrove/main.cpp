#include "ReconstructTree.h"
#include "Util.h"
using namespace std;

Vector<int> parseSequence(string sequence) {
    Vector<string> valStrs = stringSplit(sequence, ",");
    Vector<int> vals;
    for (const string& str : valStrs) {
        vals.add(stringToInteger(str));
    }
    return vals;
}

size_t NUM_BITS_IN_BYTE = 8;
string decode(Vector<TreeNode*> trees,
              Vector<Vector<int>> preorders,
              Vector<Vector<int>> inorders) {
    string res;
    char curr = 0;
    for (int i = 0; i < trees.size(); i++) {
        TreeNode* reconstructedTree = reconstructTree(preorders[i], inorders[i]);
        int val = treeEquivalence(reconstructedTree, trees[i]);
        curr = (curr << 1) | val;

        if ((i + 1) % NUM_BITS_IN_BYTE == 0) {
            res += curr;
            curr = 0;
        }
    }

    return res;
}

int main() {
    ifstream is;
    openFile(is, "puzzle.txt");
    Vector<string> lines = readLines(is);

    Vector<TreeNode*> trees = parseTrees(lines[0]);

    Vector<Vector<int>> preorders, inorders;
    for (int i = 1; i < lines.size(); i += 2) {
        preorders.add(parseSequence(lines[i]));
        inorders.add(parseSequence(lines[i + 1]));
    }

    string code = decode(trees, preorders, inorders);
    cout << "CODE: " << code << endl;

    return 0;
}
