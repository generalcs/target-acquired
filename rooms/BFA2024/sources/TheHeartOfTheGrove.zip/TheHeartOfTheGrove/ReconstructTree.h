#include "TreeNode.h"
#include "vector.h"

#ifndef RECONSTRUCTTREE_H
#define RECONSTRUCTTREE_H

TreeNode* reconstructTree(Vector<int> preorder, Vector<int> inorder);

#endif // RECONSTRUCTTREE_H
