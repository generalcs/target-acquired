#include "ReconstructTree.h"
#include "map.h"
using namespace std;


/*
 * Reconstruct the tree using only the seeds of life
 * - the preorder and inorder traversals of the tree.
 *
 * You can find the definition of [TreeNode] in [Util.h].
 */
TreeNode* reconstructTree(Vector<int> preorder, Vector<int> inorder) {
    (void) preorder;
    (void) inorder;
    return nullptr;
}
