#include "FindTheWay.h"
using namespace std;


/*
 * Find the path to the Grove's heart by navigating the left
 * and right branches of a BST according to the given value.
 *
 * Once you reach the end of the path, insert a new node with
 * the corresponding value.
 * You can find the definition of [TreeNode] in [Util.h].
 *
 */
void insertBST(TreeNode*& tree, int val) {
    /* TODO: Implement this function. */
    (void) tree;
    (void) val;
}
