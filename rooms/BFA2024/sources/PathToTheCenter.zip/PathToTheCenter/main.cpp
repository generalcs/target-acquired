#include "FindTheWay.h"
#include "Util.h"
using namespace std;

size_t NUM_BITS_IN_BYTE = 8;
string decode(Vector<TreeNode*> trees, Vector<int> vals) {
    if (trees.size() % 2 != 0) {
        error("Malformed puzzle.txt.");
    }

    string res;
    char curr = 0;
    for (int i = 0; i < trees.size() - 1; i += 2) {
        insertBST(trees[i], vals[i / 2]);
        int val = treeEquivalence(trees[i], trees[i + 1]);
        curr = (curr << 1) | val;

        if (((i + 2) / 2) % NUM_BITS_IN_BYTE == 0) {
            res += curr;
            curr = 0;
        }
    }

    return res;
}

int main() {
    ifstream is;
    openFile(is, "puzzle.txt");
    Vector<string> lines = readLines(is);

    Vector<TreeNode*> trees = parseTrees(lines[0]);


    Vector<string> valStrs = stringSplit(lines[1], ",");
    Vector<int> vals;
    for (const string& str : valStrs) {
        vals.add(stringToInteger(str));
    }

    string code = decode(trees, vals);
    cout << "CODE: " << code << endl;

    return 0;
}
