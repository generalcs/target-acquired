#include "TreeNode.h"

#ifndef FINDTHEWAY_H
#define FINDTHEWAY_H

void insertBST(TreeNode*& tree, int val);

#endif // FINDTHEWAY_H
