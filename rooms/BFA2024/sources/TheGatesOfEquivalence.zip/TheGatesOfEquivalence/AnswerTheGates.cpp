#include "AnswerTheGates.h"
using namespace std;

/*
 * Test for equivalence between the two spectral tree projections.
 * Two trees are considered 'equal' if their shape and values are
 * the same.
 *
 * You can find the definition for [TreeNode] in [util.h].
 * Once you get an answer in the console from running the program,
 * relay it to the Gates.
 */
bool treeEquivalence(TreeNode* one, TreeNode* two) {
    /* TODO: Implement this function. */
    (void) one;
    (void) two;
    return false;
}
