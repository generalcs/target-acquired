#include "AnswerTheGates.h"
#include "Util.h"
using namespace std;

size_t NUM_BITS_IN_BYTE = 8;
string decode(Vector<TreeNode*> trees) {
    if (trees.size() % 2 != 0) {
        error("Malformed puzzle.txt.");
    }

    string res;
    char curr = 0;
    for (int i = 0; i < trees.size() - 1; i += 2) {
        int val = treeEquivalence(trees[i], trees[i + 1]);
        curr = (curr << 1) | val;

        if (((i + 2) / 2) % NUM_BITS_IN_BYTE == 0) {
            res += curr;
            curr = 0;
        }
    }

    return res;
}

int main() {
    string treeSequence = readFile("puzzle.txt");
    Vector<TreeNode*> trees = parseTrees(treeSequence);

    string code = decode(trees);
    cout << "CODE: " << code << endl;

    deallocateTrees(trees);
    return 0;
}
