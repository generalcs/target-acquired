#include "TreeNode.h"

#ifndef ANSWERTHEGATES_H
#define ANSWERTHEGATES_H

bool treeEquivalence(TreeNode* one, TreeNode* two);

#endif // ANSWERTHEGATES_H
