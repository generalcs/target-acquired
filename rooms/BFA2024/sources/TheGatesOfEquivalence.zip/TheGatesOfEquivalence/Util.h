#include "TreeNode.h"
#include "vector.h"
#include "filelib.h"
#include "strlib.h"
using namespace std;

#ifndef UTIL_H
#define UTIL_H

string readFile(string filename) {
    ifstream is;
    openFile(is, filename);
    return trim(readEntire(is));
}

TreeNode* parseTree(string treeSequence, size_t& start) {
    if (treeSequence[start] == '_') {
        start += 2;
        return nullptr;
    }

    size_t numEnd = start;
    while (numEnd < treeSequence.size() && treeSequence[numEnd] != ',') {
        numEnd += 1;
    }

    int val = std::stoi(treeSequence.substr(start, numEnd - start));
    TreeNode* root = new TreeNode;
    root->val = val;
    start = numEnd + 1;

    root->left = parseTree(treeSequence, start);
    root->right = parseTree(treeSequence, start);

    return root;
}

Vector<TreeNode*> parseTrees(string treeSequence) {
    Vector<TreeNode*> trees;

    size_t start = 0;
    while (start < treeSequence.length()) {
        trees.add(parseTree(treeSequence, start));
    }

    return trees;
}

void deallocateTree(TreeNode* root) {
    if (root != nullptr) {
        deallocateTree(root->left);
        deallocateTree(root->right);
        delete root;
    }
}

void deallocateTrees(Vector<TreeNode*> trees) {
    for (TreeNode* tree : trees) {
        deallocateTree(tree);
    }
}

#endif // UTIL_H
