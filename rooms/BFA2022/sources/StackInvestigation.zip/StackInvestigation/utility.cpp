#include "utility.h"
#include "filelib.h"

using namespace std;

Node* createList(string filename) {
    ifstream in;
    openFile(in, filename);
    string contents = readEntire(in);
    Node dummy;
    Node* curr = &dummy;

    for (const char& c : contents) {
        curr->next = new Node;
        curr->next->data = c;
        curr = curr->next;
    }

    return dummy.next;
}

string getListString(Node* head) {
    string res = "";

    while (head != nullptr) {
        res += head->data;
        head = head->next;
    }

    return res;
}

void freeList(Node* head) {
    while (head != nullptr) {
        Node* next = head->next;
        delete head;
        head = next;
    }
}
