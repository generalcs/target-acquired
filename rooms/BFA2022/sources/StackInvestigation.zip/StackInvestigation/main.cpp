#include <iostream>
#include "utility.h"
using namespace std;

/* Node definition (DO NOT UNCOMMENT):
struct Node {
    char data;
    Node* next = nullptr;
};
*/

/* Filter out ASCII value characters in range 100-109. Returns the head of the new list.
 * This will be sufficient to get rid of the useless packets and malicious noise. */
/* IN-PLACE LIST MODIFICATION W/O ALLOCATING NEW NODES */
Node* filter(Node* traffic) {
    return traffic;
}

/* DO NOT MODIFY CODE OR SET BREAKPOINTS BELOW THIS LINE */
int main() {
    Node* traffic = createList("traffic.txt");
    traffic = filter(traffic);
    cout << "FILTERED: " << getListString(traffic) << endl;
    free(traffic);
    return 0;
}
