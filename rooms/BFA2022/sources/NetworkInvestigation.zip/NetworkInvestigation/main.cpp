using namespace std;

/* * * YOU CAN NEVER CATCH US. * * */
struct Node {
    int data;
    Node* next;
};

// Internal: PIPELINE DEFINITION

// Internal: to deactivate, collect all the function names where
// the function modifies the STRUCT that the POINTER is pointing TO.
// The code can be deduced from these names in the order that they
// are written here.

void third(Node* ptr) {
    ptr = new Node;
    ptr->data = 5;
    delete ptr;
}

void ip(Node* ptr) {
    ptr->data = 10;
}

void second(Node* ptr) {
    ptr->data = 5823;
}

void letter(Node* ptr) {
    Node* head = ptr;
    head->data = 10;
}

int byte(Node* ptr) {
    int num = ptr->data;
    num += 10;
    return num;
}

void request(Node* ptr) {
    Node* leading = ptr;
    leading = new Node;
    delete leading;
}

void stands(Node* ptr) {
    int* num = &(ptr->data);
    *num = 203;
}

void four(Node* ptr) {
    ptr->next = nullptr;
}

/* * * YOU CAN NEVER CATCH US. * * */

int main() {
    return 0;
}
