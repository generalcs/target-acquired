#ifndef UTILITY_H
#define UTILITY_H

#include <string>

struct Node {
    char data;
    Node* next = nullptr;
};

Node* createList(std::string filename);

std::string getListString(Node* head);

void freeList(Node* head);

#endif // UTILITY_H
