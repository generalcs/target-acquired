#include <iostream>
#include "destructlist.h"
#include "filelib.h"
using namespace std;

/* Node definition (DO NOT UNCOMMENT):
struct Node {
    char data;
    Node* next = nullptr;
};
*/

/* Implement the functions below to decrypt the self-destruct code.
 * Once your team finds the code, you'll be able to wipe all the breached nodes.
 * Return the head of the resulting list for each function.
 * IN-PLACE MODIFICATION OF LIST WITHOUT ALLOCATING NEW NODES */
Node* evenOdd(Node* code) {
    return code;
}

Node* reverse(Node* code) {
    return code;
}

Node* skip(Node* code) {
    return code;
}

/* DO NOT MODIFY CODE OR SET BREAKPOINTS BELOW THIS LINE */
int main() {
    DestructList destructOps(readEntireFile("encrypted.txt"));
    Node* interleaved = evenOdd(destructOps.getCode());
    Node* reversed = reverse(interleaved);
    Node* skipped = skip(reversed);
    cout << endl << "DECRYPTED CODE: " << destructOps.getCodeString(skipped) << endl;
    destructOps.freeCode(skipped);
    return 0;
}
