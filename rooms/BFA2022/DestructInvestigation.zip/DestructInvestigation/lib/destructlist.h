#ifndef DESTRUCTLIST_H
#define DESTRUCTLIST_H

#include "DestructList_global.h"

struct DESTRUCTLIST_EXPORT Node {
    char data;
    Node* next = nullptr;
};

class DESTRUCTLIST_EXPORT DestructList
{
public:
    DestructList(std::string encryptedCode);

    Node* getCode();
    std::string getCodeString(Node* code);

    void freeCode(Node* code);

private:
    Node* code;

    void createCode(std::string encryptedCode);
};

#endif // DESTRUCTLIST_H
