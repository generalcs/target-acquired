#ifndef VAULTLIST_GLOBAL_H
#define VAULTLIST_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(VAULTLIST_LIBRARY)
#  define VAULTLIST_EXPORT Q_DECL_EXPORT
#else
#  define VAULTLIST_EXPORT Q_DECL_IMPORT
#endif

#endif // VAULTLIST_GLOBAL_H
