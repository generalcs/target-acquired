#ifndef VAULTLIST_H
#define VAULTLIST_H

#include "VaultList_global.h"

struct VAULTLIST_EXPORT Node {
    char data;
    Node* next = nullptr;
};

class VAULTLIST_EXPORT VaultList
{
public:
    VaultList(std::string wheelString);
    ~VaultList();

    Node* getVaultWheel();

private:
    Node* wheel;

    void createWheel(std::string wheelString);
    void freeWheel();
};

#endif // VAULTLIST_H
