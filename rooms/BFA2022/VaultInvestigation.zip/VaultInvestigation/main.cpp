#include <string>
#include "vaultlist.h"
#include "filelib.h"
using namespace std;

/*
 * The vault wheel is represented as a linked list of nodes containing chars. One "turn"
 * of the wheel is equivalent to skipping one char. Each ASCII value for a character
 * in string code indicates the number of turns on the wheel until reaching a character of the
 * login. The software mechanism below implements the translation between turns and
 * login characters, but the wheel gets stuck. Seems like the wheel is being turned too much.
 */
string turnWheel(Node* wheel, string code) {
    string login = "";

    for (const char& c : code) {
        for (int i = 0; i < (int) c; i++) {
            wheel = wheel->next;
        }

        login += wheel->data;
    }

    return login;
}

/* DO NOT MODIFY CODE OR SET BREAKPOINTS BELOW THIS LINE */
int main() {
    VaultList vault(readEntireFile("vaultWheel.txt"));
    cout << endl << "LOGIN USERNAME: " << turnWheel(vault.getVaultWheel(), "x4a32fiq0") << endl;
    return 0;
}
