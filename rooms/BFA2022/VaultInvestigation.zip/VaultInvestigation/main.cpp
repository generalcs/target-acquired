#include <iostream>
#include "utility.h"

using namespace std;

/*
 * Author: Fred
 * Idk why this is not working
 * Head is not supposed to change because I am shifting values once backwards, not nodes
 * Can someone else run this??
 *
 * Test case:
 * a -> b -> c should turn into b -> c -> a, into c -> a -> b after another call
 */
void rotate(Node* head) {
    while (head != nullptr) {
        head->data = head->next->data;
        head = head->next;
    }
}

/* Code below is working...*/
string getLogin(Node* head, string code) {
    string login = "";

    for (const char& c : code) {
        for (int i = 0; i < c; i++) {
            rotate(head);
        }

        login += head->data;
    }

    return login;
}

int main() {
    Node* list = createList("vaultWheel.txt");
    cout << "LOGIN PASSWORD: " << getLogin(list, "x4a32fi") << endl;
    freeList(list);
    return 0;
}
