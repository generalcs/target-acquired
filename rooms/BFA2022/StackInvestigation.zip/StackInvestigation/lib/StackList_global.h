#ifndef STACKLIST_GLOBAL_H
#define STACKLIST_GLOBAL_H

#include <QtCore/qglobal.h>

#if defined(STACKLIST_LIBRARY)
#  define STACKLIST_EXPORT Q_DECL_EXPORT
#else
#  define STACKLIST_EXPORT Q_DECL_IMPORT
#endif

#endif // STACKLIST_GLOBAL_H
