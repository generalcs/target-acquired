#ifndef STACKLIST_H
#define STACKLIST_H

#include "StackList_global.h"

struct STACKLIST_EXPORT Node {
    char data;
    Node* next = nullptr;
};

class STACKLIST_EXPORT StackList
{
public:
    StackList(std::string trafficString);

    Node* getTraffic();
    void setTraffic(Node* traffic);

    std::string getTrafficString();

    void freeTraffic();

private:
    Node* traffic;

    void createTraffic(std::string trafficString);
};

#endif // STACKLIST_H
