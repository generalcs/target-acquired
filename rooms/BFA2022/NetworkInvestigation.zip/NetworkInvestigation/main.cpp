using namespace std;

struct Node {
    int data;
    Node* next = nullptr;
};

/*
 * Some of these transmission functions make modifications to the node struct
 * that dataPtr is pointing at. Collect the names of these functions that breach
 * the original struct in ANY WAY.
 */

void third(Node* dataPtr) {
    dataPtr = new Node;
    dataPtr->data = 42;
    dataPtr->next = nullptr;
    delete dataPtr;
}

void four(Node* dataPtr) {
    dataPtr->next = new Node;
    dataPtr->next->data = 2718;
    dataPtr->next->next = nullptr;
}

void byte(Node* dataPtr) {
    dataPtr->data = 5;
}

void request(Node* dataPtr) {
    Node* ref = dataPtr;
    Node refNode = *ref;
    refNode.data = 3;
}

void id(Node* dataPtr) {
    Node& ref = *(*(&(*(&dataPtr))));
    ref.data = 6;
}

void five(Node* dataPtr) {
    Node node = *(dataPtr->next);
    node.data = 3920;
}

int client(Node* dataPtr) {
    int num = dataPtr->data;
    num += 5830;
    return num;
}

void second(Node* dataPtr) {
    Node** ref = &dataPtr;
    (*(*ref)).data = 5;
}

void letter(Node* dataPtr) {
    Node** next = &(dataPtr->next);
    *next = nullptr;
}

int main() {
    return 0;
}
